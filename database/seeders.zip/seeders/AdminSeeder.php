<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'name' => 'Admin Happy Shop',
            'email' => 'admin@happyshop.id',
            'password' => Hash::make('password123'),
            'email_verified_at' => now(),
        ]);
    }
}
